#!/usr/bin/env python3
"""MCP-сервер «notebooklm» (stdio): доступ к блокнотам NotebookLM через notebooklm-py.

Обёртка вокруг неофициального клиента notebooklm-py 0.8.0 (Python-API, не CLI).

Как пакет ходит в сеть (проверено по исходникам 0.8.0):
  * ВСЕ рабочие команды (список блокнотов, вопрос, источники) идут ЧИСТЫМ HTTP
    через httpx.AsyncClient с куками из storage_state.json:
    notebooklm/_runtime/transport.py, notebooklm/_rpc_executor.py,
    notebooklm/_streaming_post.py, notebooklm/_kernel.py.
  * Playwright нужен ТОЛЬКО для интерактивного `notebooklm login` и для
    необязательного «headless re-auth» (notebooklm/cli/services/playwright_login.py,
    notebooklm/_auth/browser_capture.py, notebooklm/_auth/headless_reauth.py).
    Импорт playwright — ленивый; без него всё остальное работает.
    => На сервере playwright и chromium НЕ нужны. Куки приезжают готовыми
       с компьютера Максима.
  * Есть необязательный транспорт curl_cffi (NOTEBOOKLM_TRANSPORT=curl_cffi) —
    по умолчанию выключен, ставить не требуется.

Аутентификация: файл storage_state.json (формат Playwright storage state).
  На сервере: /home/hermes/.notebooklm/profiles/default/storage_state.json
  Переопределяется переменной NOTEBOOKLM_STORAGE.
  Файл должен быть ДОСТУПЕН НА ЗАПИСЬ: клиент дописывает в него ротированные
  куки при закрытии сессии (notebooklm/_runtime/lifecycle.py -> save_cookies),
  это продлевает жизнь сессии. Права: chmod 600, владелец hermes.

Деплой: /home/hermes/notebooklm-mcp/server.py + venv + run.sh;
        регистрация `hermes mcp add notebooklm`.
  python3 -m venv /home/hermes/notebooklm-mcp/.venv
  /home/hermes/notebooklm-mcp/.venv/bin/pip install "mcp==1.28.1" "notebooklm-py==0.8.0"
  (playwright / chromium / fastmcp / fastapi НЕ нужны)

Почему Python-API, а не subprocess к CLI (NOTEBOOKLM_BIN): у пакета стабильный
публичный API (NotebookLMClient.from_storage / notebooks.list / sources.list /
chat.ask) с типизированными результатами, включая цитаты (ChatReference.cited_text).
Разбирать вывод CLI не нужно, лишний процесс на каждый вызов — тоже.
Если notebooklm-py стоит в ДРУГОМ venv, путь к его site-packages можно передать
переменной NOTEBOOKLM_SITE_PACKAGES (добавится в sys.path).

Самопроверка без сети: python3 server.py --selftest
"""
import asyncio
import json
import os
import re
import sys
from pathlib import Path

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent


# ------------------------------- настройки из окружения -------------------------------

def _env_num(name, default, cast):
    """Число из окружения; мусор в переменной не роняет сервер."""
    try:
        return cast(os.environ[name])
    except (KeyError, TypeError, ValueError):
        return default


# Пакет notebooklm-py может лежать в другом venv — тогда путь к его site-packages
# приезжает переменной окружения (добавляем ДО первого импорта пакета).
_SITE_PACKAGES = (os.environ.get("NOTEBOOKLM_SITE_PACKAGES") or "").strip()
if _SITE_PACKAGES and _SITE_PACKAGES not in sys.path:
    sys.path.append(_SITE_PACKAGES)


def _storage_path():
    """Путь к storage_state.json: NOTEBOOKLM_STORAGE > ~/.notebooklm/... > /home/hermes/...

    Считаем на каждый вызов, а не один раз при старте: куки на сервер могут
    привезти уже после запуска сервера, и перезапускать его ради этого незачем.
    """
    explicit = (os.environ.get("NOTEBOOKLM_STORAGE") or "").strip()
    if explicit:
        return Path(explicit).expanduser()
    candidates = [
        Path.home() / ".notebooklm" / "profiles" / "default" / "storage_state.json",
        Path("/home/hermes/.notebooklm/profiles/default/storage_state.json"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return candidates[0]


# Таймауты щедрые: NotebookLM думает над вопросом десятки секунд, иногда минуту-две.
HTTP_TIMEOUT = _env_num("NOTEBOOKLM_TIMEOUT", 60.0, float)        # обычные RPC (список и т.п.)
CHAT_TIMEOUT = _env_num("NOTEBOOKLM_CHAT_TIMEOUT", 300.0, float)  # чтение ответа на вопрос
ASK_DEADLINE = _env_num("NOTEBOOKLM_ASK_DEADLINE", 600.0, float)  # общий предохранитель на ask
LIST_DEADLINE = _env_num("NOTEBOOKLM_LIST_DEADLINE", 180.0, float)  # предохранитель на список
MAX_CITATIONS = _env_num("NOTEBOOKLM_MAX_CITATIONS", 12, int)     # сколько цитат показывать
CITATION_CHARS = _env_num("NOTEBOOKLM_CITATION_CHARS", 700, int)  # длина одной цитаты, знаков

# Текст, обязательный к выдаче при любой проблеме с аутентификацией.
AUTH_EXPIRED_TEXT = (
    "Ошибка: сессия NotebookLM истекла. Попросите Максима выполнить notebooklm login "
    "на его компьютере и обновить куки на сервере. Сам не чини."
)


class ToolError(Exception):
    """Понятная пользователю ошибка — печатается как «Ошибка: <текст>», без имени класса."""


class AuthProblem(Exception):
    """Проблема с аутентификацией, обнаруженная до обращения к сети (нет файла с куками)."""


# ------------------------------- распознавание ошибок -------------------------------

# Признаки протухшей/отсутствующей аутентификации. Пакет сигналит о ней РАЗНЫМИ
# способами, поэтому ловим и типы, и тексты:
#   * ValueError("Authentication expired. Run 'notebooklm login' to re-authenticate.")
#     — notebooklm/_auth/session.py (мёртвые куки, редирект на accounts.google.com);
#   * ValueError("Authentication expired or invalid. Run 'notebooklm login' ...")
#     — notebooklm/_auth/extraction.py (не извлеклись SNlM0e/FdrFJe);
#   * FileNotFoundError("Storage file not found: ... Run 'notebooklm login' ...")
#     — notebooklm/_auth/cookies.py (нет файла с куками);
#   * AuthError / AuthExtractionError — notebooklm/exceptions.py;
#   * RPCError("HTTP 401 calling ...") / "HTTP 403 ..." — notebooklm/_rpc_executor.py:
#     401/403 после исчерпания авто-refresh поднимаются голым RPCError, не AuthError.
_AUTH_MARKERS = (
    "authentication expired",
    "authentication failed",
    "authentication is invalid",
    "notebooklm login",
    "storage file not found",
    "http 401",
    "http 403",
)
_AUTH_EXC_NAMES = frozenset({"AuthError", "AuthExtractionError"})

# Региональный/антифрод-шлюз Google (частая история для датацентровых IP).
# Это НЕ протухшая сессия, и «перелогиниться» тут не поможет — сообщение отдельное.
# Источник текста: notebooklm/_auth/extraction.py -> _unavailable_redirect_message.
_GATE_MARKERS = (
    "access gate",
    "region / anti-abuse",
    "location=unsupported",
)


def _exc_chain(exc, depth=6):
    """Исключение и его причины (__cause__/__context__) — ошибка часто завёрнута."""
    chain = []
    current = exc
    while current is not None and len(chain) < depth:
        chain.append(current)
        current = current.__cause__ or current.__context__
    return chain


def _classify_error(exc):
    """«auth» — протухшая/отсутствующая сессия, «gate» — региональный шлюз, «other» — прочее."""
    for item in _exc_chain(exc):
        text = " ".join(str(item).split()).casefold()
        names = {cls.__name__ for cls in type(item).__mro__}
        if any(marker in text for marker in _GATE_MARKERS):
            return "gate"
        if names & _AUTH_EXC_NAMES:
            return "auth"
        if isinstance(item, FileNotFoundError) and "storage" in text:
            return "auth"
        if any(marker in text for marker in _AUTH_MARKERS):
            return "auth"
    return "other"


def _auth_error_text(detail=""):
    """Обязательная формулировка про истёкшую сессию + техническая деталь для Максима."""
    text = AUTH_EXPIRED_TEXT
    if detail:
        text += f"\n\nТехническая деталь (для Максима, не для самолечения): {detail}"
    text += f"\nФайл с куками на сервере: {_storage_path()}"
    return text


def _gate_error_text(detail):
    """Отказ Google по IP/региону — перелогин не помогает, чиним не мы."""
    return (
        "Ошибка: NotebookLM не пустил запрос с этого сервера — сработал региональный "
        "(антифрод) фильтр Google. Это не истёкшая сессия, перелогин не поможет: нужен "
        "другой IP или прокси для сервера. Сообщите Максиму.\n\n"
        f"Техническая деталь: {detail}"
    )


def _friendly_other(exc):
    """Человеческая формулировка для частых не-аутентификационных сбоев."""
    names = set()
    for item in _exc_chain(exc):
        names.update(cls.__name__ for cls in type(item).__mro__)
    if "RateLimitError" in names:
        return ("Ошибка: NotebookLM ограничил частоту запросов (rate limit). "
                f"Повторите через несколько минут. Деталь: {_short(exc)}")
    if any("Timeout" in name for name in names):
        return ("Ошибка: NotebookLM не ответил вовремя. Повторите запрос; "
                f"если вопрос сложный — задайте его короче. Деталь: {_short(exc)}")
    if "ChatError" in names:
        return ("Ошибка: NotebookLM не довёл ответ до конца (не записал реплику в диалог "
                f"блокнота). Задайте вопрос ещё раз. Деталь: {_short(exc)}")
    if "ServerError" in names:
        return ("Ошибка: сбой на стороне Google (NotebookLM). Повторите позже. "
                f"Деталь: {_short(exc)}")
    return f"Ошибка: {_short(exc)}"


def _short(exc):
    """Короткое человекочитаемое представление исключения."""
    text = " ".join(str(exc).split())
    if len(text) > 400:
        text = text[:400] + "…"
    return f"{type(exc).__name__}: {text}" if text else type(exc).__name__


# ------------------------------- клиент notebooklm-py -------------------------------

def _client_factory():
    """Ленивый импорт: сервер должен запускаться и без пакета (чтобы --selftest сказал, чего нет)."""
    try:
        from notebooklm import NotebookLMClient
    except Exception as exc:  # ImportError и любой сбой инициализации пакета
        raise ToolError(
            "в окружении сервера нет рабочего пакета notebooklm-py "
            f"({_short(exc)}). Установите его в тот же venv, где стоит mcp: "
            "pip install notebooklm-py==0.8.0 — или укажите путь к его site-packages "
            "в переменной окружения NOTEBOOKLM_SITE_PACKAGES."
        ) from exc
    return NotebookLMClient


def _open_client():
    """Открытая сессия NotebookLM (async context manager).

    from_storage сам читает куки из файла и добирает CSRF-токены с домашней страницы
    (один HTTP-GET), поэтому именно здесь чаще всего и вылезает протухшая сессия.
    Клиент создаётся на каждый вызов инструмента: он привязан к event loop и держит
    пул соединений — короткая жизнь надёжнее, чем долгоживущий синглтон.
    """
    if not _storage_path().exists():
        raise AuthProblem("на сервере нет файла с куками NotebookLM (Storage file not found)")
    client_cls = _client_factory()
    return client_cls.from_storage(
        path=str(_storage_path()),
        timeout=HTTP_TIMEOUT,
        chat_timeout=CHAT_TIMEOUT,
        # Пустой блокнот/пустая выдача — норма; ретраи оставляем как в пакете.
    )


# ------------------------------- поиск блокнота -------------------------------

_ID_RE = re.compile(r"^[0-9a-fA-F][0-9a-fA-F-]{15,}$")


def _looks_like_id(value):
    """Похоже на полный id блокнота (UUID-подобная строка)."""
    return bool(_ID_RE.match(value))


def _describe(notebook):
    """«Название» (id) — для сообщений об ошибках и заголовков."""
    title = (getattr(notebook, "title", "") or "").strip() or "без названия"
    return f"«{title}» (id: {notebook.id})"


async def _resolve_notebook(client, query):
    """Найти блокнот по id, началу id или названию. Возвращает (id, название)."""
    query = (query or "").strip()
    if not query:
        raise ToolError("не указан блокнот. Передайте id блокнота, его начало или точное название.")

    notebooks = await client.notebooks.list()
    lowered = query.casefold()

    exact_id = [nb for nb in notebooks if nb.id == query]
    if exact_id:
        return exact_id[0].id, (exact_id[0].title or "").strip()

    by_prefix = [nb for nb in notebooks if nb.id.casefold().startswith(lowered)]
    if len(by_prefix) == 1:
        return by_prefix[0].id, (by_prefix[0].title or "").strip()
    if len(by_prefix) > 1:
        raise ToolError(
            f"под «{query}» подходит несколько блокнотов: "
            + "; ".join(_describe(nb) for nb in by_prefix[:10])
            + ". Уточните id полностью."
        )

    by_title = [nb for nb in notebooks if (nb.title or "").strip().casefold() == lowered]
    if len(by_title) == 1:
        return by_title[0].id, (by_title[0].title or "").strip()
    if len(by_title) > 1:
        raise ToolError(
            f"блокнотов с названием «{query}» несколько: "
            + "; ".join(_describe(nb) for nb in by_title[:10])
            + ". Укажите id."
        )

    by_substring = [nb for nb in notebooks if lowered in (nb.title or "").casefold()]
    if len(by_substring) == 1:
        return by_substring[0].id, (by_substring[0].title or "").strip()
    if len(by_substring) > 1:
        raise ToolError(
            f"под «{query}» подходит несколько блокнотов: "
            + "; ".join(_describe(nb) for nb in by_substring[:10])
            + ". Уточните название или укажите id."
        )

    # Блокнота нет в списке: список отдаёт «недавно просмотренные». Если запрос
    # выглядит как полный id — пробуем работать с ним напрямую.
    if _looks_like_id(query):
        return query, ""

    known = ", ".join(f"«{(nb.title or '').strip()}»" for nb in notebooks[:15]) or "список пуст"
    raise ToolError(
        f"блокнот «{query}» не найден. Доступные блокноты: {known}. "
        "Полный список — инструментом list_notebooks."
    )


# ------------------------------- форматирование -------------------------------

_SOURCE_TYPE_RU = {
    "google_docs": "Google Документ",
    "google_slides": "Google Презентация",
    "google_spreadsheet": "Google Таблица",
    "pdf": "PDF",
    "pasted_text": "вставленный текст",
    "web_page": "веб-страница",
    "google_drive_audio": "аудио с Google Диска",
    "google_drive_video": "видео с Google Диска",
    "youtube": "видео YouTube",
    "markdown": "Markdown",
    "docx": "DOCX",
    "csv": "CSV",
    "epub": "EPUB",
    "image": "изображение",
    "media": "медиафайл",
    "unknown": "тип не распознан",
}

_SOURCE_STATUS_RU = {
    1: "обрабатывается",
    2: "готов",
    3: "ошибка обработки",
    5: "загружается",
}


def _source_kind_ru(source):
    """Русское название типа источника; неизвестный код не роняет выдачу."""
    try:
        kind = source.kind
        code = getattr(kind, "value", kind)
    except Exception:
        return "тип не распознан"
    return _SOURCE_TYPE_RU.get(str(code), str(code))


def _source_status_ru(source):
    """Статус источника; «готов» не печатаем — это норма."""
    status = getattr(source, "status", None)
    code = getattr(status, "value", status)
    try:
        code = int(code)
    except (TypeError, ValueError):
        return ""
    if code == 2:
        return ""
    return _SOURCE_STATUS_RU.get(code, f"статус {code}")


def _format_notebooks(notebooks):
    """Список блокнотов в Markdown."""
    if not notebooks:
        return (
            "В аккаунте NotebookLM не найдено ни одного блокнота. "
            "Возможно, куки принадлежат другому аккаунту Google."
        )
    lines = [f"**Блокноты NotebookLM: {len(notebooks)}**", ""]
    for index, notebook in enumerate(notebooks, start=1):
        title = (notebook.title or "").strip() or "без названия"
        count = getattr(notebook, "sources_count", 0) or 0
        lines.append(f"{index}. **{title}** — источников: {count}")
        lines.append(f"   id: `{notebook.id}`")
    lines += [
        "",
        "Порядок — от недавно открытых к старым (NotebookLM отдаёт список именно так). "
        "Чтобы задать вопрос по материалам блокнота — ask_notebook, "
        "посмотреть состав материалов — notebook_sources.",
    ]
    return "\n".join(lines)


def _format_sources(title, notebook_id, sources):
    """Состав блокнота в Markdown."""
    heading = f"**Блокнот:** {title or 'без названия'}\n**id:** `{notebook_id}`"
    if not sources:
        return heading + "\n\nВ блокноте нет источников."
    lines = [heading, "", f"**Источников: {len(sources)}**", ""]
    for index, source in enumerate(sources, start=1):
        name = (getattr(source, "title", "") or "").strip() or "без названия"
        marks = [_source_kind_ru(source)]
        status = _source_status_ru(source)
        if status:
            marks.append(status)
        lines.append(f"{index}. {name} — {', '.join(marks)}")
        url = getattr(source, "url", None)
        if url:
            lines.append(f"   {url}")
    return "\n".join(lines)


def _clean(text):
    """Схлопнуть переносы внутри цитаты, чтобы она читалась одной строкой."""
    return " ".join((text or "").split())


def _format_answer(title, notebook_id, question, result, source_titles):
    """Ответ блокнота + цитаты из источников."""
    answer = (getattr(result, "answer", "") or "").strip()
    lines = [
        f"**Блокнот:** {title or 'без названия'} (id: `{notebook_id}`)",
        f"**Вопрос:** {question}",
        "",
        answer or "_NotebookLM вернул пустой ответ._",
    ]

    references = list(getattr(result, "references", None) or [])
    if references:
        shown = references[:MAX_CITATIONS]
        lines += ["", "---", "", f"**Ссылки на источники ({len(references)}):**", ""]
        for index, ref in enumerate(shown, start=1):
            number = getattr(ref, "citation_number", None) or index
            source_id = getattr(ref, "source_id", "") or ""
            name = source_titles.get(source_id) or f"источник {source_id or '?'}"
            lines.append(f"[{number}] {name}")
            cited = _clean(getattr(ref, "cited_text", None))
            if cited:
                if len(cited) > CITATION_CHARS:
                    cited = cited[:CITATION_CHARS] + "…"
                lines.append(f"    «{cited}»")
        if len(references) > len(shown):
            lines.append(f"    … и ещё {len(references) - len(shown)} ссылок.")
        lines += [
            "",
            "Фрагменты в кавычках — то, что NotebookLM вернул как процитированный кусок "
            "источника. Перед вставкой в документ сверить с самим источником.",
        ]
    else:
        lines += [
            "",
            "---",
            "",
            "NotebookLM не приложил ссылок на источники к этому ответу.",
        ]

    lines += [
        "",
        "Ответ сформулирован моделью NotebookLM по материалам блокнота — это пересказ, "
        "а не дословный текст источников.",
    ]
    return "\n".join(lines)


# ------------------------------- MCP -------------------------------

app = Server("notebooklm")

TOOLS = [
    Tool(
        name="list_notebooks",
        description=(
            "Список блокнотов NotebookLM пользователя. Возвращает название, id и количество "
            "источников по каждому блокноту. Применять, когда нужно понять, какие блокноты "
            "вообще есть, или узнать id блокнота для ask_notebook / notebook_sources: "
            "«какие у меня блокноты», «что есть в NotebookLM», «найди блокнот про …»."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="ask_notebook",
        description=(
            "Задать вопрос по материалам конкретного блокнота NotebookLM; ответ приходит "
            "пересказом через модель NotebookLM — для дословных цитат не годится. "
            "Возвращает ответ и, если NotebookLM их приложил, ссылки на источники с "
            "процитированными фрагментами. Применять для вопросов по загруженным в блокнот "
            "материалам: «что в блокноте сказано про …», «спроси у блокнота …». "
            "Вопрос продолжает текущий диалог блокнота — как в веб-интерфейсе NotebookLM. "
            "Думает долго: до нескольких минут."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "notebook": {
                    "type": "string",
                    "description": (
                        "Блокнот: полный id, начало id или точное название "
                        "(список — инструментом list_notebooks)"
                    ),
                },
                "question": {
                    "type": "string",
                    "description": "Вопрос по материалам блокнота, обычным текстом",
                },
            },
            "required": ["notebook", "question"],
        },
    ),
    Tool(
        name="notebook_sources",
        description=(
            "Какие материалы лежат в блокноте: список источников блокнота NotebookLM "
            "(название, тип, ссылка, статус обработки). Применять перед вопросом к блокноту — "
            "проверить, что нужный документ в него загружен: «что в блокноте», «какие "
            "материалы загружены», «есть ли там договор …»."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "notebook": {
                    "type": "string",
                    "description": (
                        "Блокнот: полный id, начало id или точное название "
                        "(список — инструментом list_notebooks)"
                    ),
                },
            },
            "required": ["notebook"],
        },
    ),
]


@app.list_tools()
async def list_tools():
    return TOOLS


async def _tool_list_notebooks():
    """Список блокнотов."""
    async with _open_client() as client:
        notebooks = await client.notebooks.list()
    return _format_notebooks(notebooks)


async def _tool_notebook_sources(notebook_query):
    """Источники одного блокнота."""
    async with _open_client() as client:
        notebook_id, title = await _resolve_notebook(client, notebook_query)
        sources = await client.sources.list(notebook_id)
    return _format_sources(title, notebook_id, sources)


async def _tool_ask_notebook(notebook_query, question):
    """Вопрос к блокноту + подтягивание названий источников для цитат."""
    question = (question or "").strip()
    if not question:
        raise ToolError("пустой вопрос.")
    async with _open_client() as client:
        notebook_id, title = await _resolve_notebook(client, notebook_query)
        result = await client.chat.ask(notebook_id, question)
        # Названия источников нужны, чтобы цитаты не выглядели как голые UUID.
        # Сбой этого запроса не должен убивать уже полученный ответ.
        source_titles = {}
        try:
            for source in await client.sources.list(notebook_id):
                source_titles[source.id] = (getattr(source, "title", "") or "").strip()
        except Exception:
            source_titles = {}
    return _format_answer(title, notebook_id, question, result, source_titles)


@app.call_tool()
async def call_tool(name, arguments):
    arguments = arguments or {}
    try:
        if name == "list_notebooks":
            text = await asyncio.wait_for(_tool_list_notebooks(), timeout=LIST_DEADLINE)
            return [TextContent(type="text", text=text)]

        if name == "notebook_sources":
            text = await asyncio.wait_for(
                _tool_notebook_sources(arguments.get("notebook")), timeout=LIST_DEADLINE
            )
            return [TextContent(type="text", text=text)]

        if name == "ask_notebook":
            text = await asyncio.wait_for(
                _tool_ask_notebook(arguments.get("notebook"), arguments.get("question")),
                timeout=ASK_DEADLINE,
            )
            return [TextContent(type="text", text=text)]

        return [TextContent(type="text", text=f"Ошибка: неизвестный инструмент «{name}».")]

    except AuthProblem as exc:
        # Нет файла с куками — та же беда, что и протухшая сессия.
        return [TextContent(type="text", text=_auth_error_text(str(exc)))]

    except ToolError as exc:
        return [TextContent(type="text", text=f"Ошибка: {exc}")]

    except asyncio.TimeoutError:
        limit = int(ASK_DEADLINE if name == "ask_notebook" else LIST_DEADLINE)
        return [TextContent(type="text", text=(
            f"Ошибка: NotebookLM не ответил за {limit} с. Повторите запрос позже; "
            "если вопрос сложный — задайте его короче."
        ))]

    except Exception as exc:
        kind = _classify_error(exc)
        if kind == "auth":
            return [TextContent(type="text", text=_auth_error_text(_short(exc)))]
        if kind == "gate":
            return [TextContent(type="text", text=_gate_error_text(_short(exc)))]
        return [TextContent(type="text", text=_friendly_other(exc))]


# ------------------------------- самопроверка -------------------------------

class _FakeNotebook:
    def __init__(self, notebook_id, title, sources_count):
        self.id = notebook_id
        self.title = title
        self.sources_count = sources_count


class _FakeSource:
    def __init__(self, source_id, title, kind, status, url=None):
        self.id = source_id
        self.title = title
        self.kind = kind
        self.status = status
        self.url = url


class _FakeRef:
    def __init__(self, source_id, number, cited_text):
        self.source_id = source_id
        self.citation_number = number
        self.cited_text = cited_text


class _FakeResult:
    def __init__(self, answer, references):
        self.answer = answer
        self.references = references


def _selftest():
    """Проверка без сети: импорт клиента, файл с куками, сборка инструментов, разбор ошибок."""
    failures = []
    print("== selftest notebooklm-mcp ==")

    print(f"[1/5] файл с куками: {_storage_path()}")
    if _storage_path().exists():
        try:
            data = json.loads(_storage_path().read_text(encoding="utf-8"))
            cookies = data.get("cookies") if isinstance(data, dict) else None
            names = sorted({c.get("name", "") for c in cookies or [] if isinstance(c, dict)})
            print(f"      есть, куки: {len(cookies or [])} шт.")
            important = [n for n in ("SID", "__Secure-1PSID", "__Secure-1PSIDTS") if n in names]
            print(f"      ключевые куки на месте: {', '.join(important) or 'НЕ НАЙДЕНЫ'}")
            if not important:
                print("      ПРЕДУПРЕЖДЕНИЕ: в файле нет ни одной ключевой куки Google.")
        except Exception as exc:
            failures.append(f"файл с куками не читается: {_short(exc)}")
            print(f"      ПРОВАЛ: {_short(exc)}")
    else:
        print("      ПРЕДУПРЕЖДЕНИЕ: файла нет. На сервере он должен лежать по пути "
              "/home/hermes/.notebooklm/profiles/default/storage_state.json "
              "(или укажите NOTEBOOKLM_STORAGE). Без него сервер запустится, "
              "но каждый вызов вернёт «сессия NotebookLM истекла».")

    print("[2/5] импорт клиента notebooklm-py")
    try:
        import importlib.util

        client_cls = _client_factory()
        import notebooklm

        print(f"      notebooklm-py {getattr(notebooklm, '__version__', '?')}, "
              f"{client_cls.__name__}.from_storage — "
              f"{'есть' if hasattr(client_cls, 'from_storage') else 'НЕТ'}")
        if not hasattr(client_cls, "from_storage"):
            failures.append("у клиента нет from_storage")
        # Рабочие команды обязаны ходить httpx, а не браузером: убеждаемся, что
        # транспортный модуль держит именно httpx-клиент.
        import notebooklm._runtime.transport as _transport

        if getattr(_transport, "httpx", None) is None:
            failures.append("в notebooklm._runtime.transport нет httpx — транспорт изменился")
            print("      ПРОВАЛ: транспорт больше не httpx, проверьте версию пакета")
        else:
            print("      транспорт рабочих команд: httpx (браузер не нужен)")
        has_playwright = importlib.util.find_spec("playwright") is not None
        print(f"      playwright в окружении: {'есть' if has_playwright else 'нет'} "
              "— для list/ask/sources он и не требуется (нужен только для notebooklm login)")
    except ToolError as exc:
        failures.append(str(exc))
        print(f"      ПРОВАЛ: {exc}")
    except Exception as exc:
        failures.append(f"импорт notebooklm: {_short(exc)}")
        print(f"      ПРОВАЛ: {_short(exc)}")

    print("[3/5] сборка списка инструментов")
    try:
        for tool in TOOLS:
            schema = tool.inputSchema
            json.dumps(schema, ensure_ascii=False)
            assert tool.name and tool.description, "у инструмента нет имени или описания"
            assert schema.get("type") == "object", f"{tool.name}: inputSchema не object"
            for required in schema.get("required", []):
                assert required in schema.get("properties", {}), \
                    f"{tool.name}: обязательный параметр {required} не описан"
            print(f"      {tool.name}: ok, параметры: "
                  f"{', '.join(schema.get('properties', {})) or 'нет'}")
        assert len(TOOLS) == 3, "ожидалось 3 инструмента"
        assert hasattr(app, "list_tools") and hasattr(app, "call_tool"), \
            "Server не выглядит как mcp 1.x"
        print(f"      сервер «notebooklm», инструментов: {len(TOOLS)}")
    except Exception as exc:
        failures.append(f"инструменты: {_short(exc)}")
        print(f"      ПРОВАЛ: {_short(exc)}")

    print("[4/5] разбор ошибок аутентификации")
    cases = [
        (ValueError("Authentication expired. Run 'notebooklm login' to re-authenticate."), "auth"),
        (ValueError("Authentication expired or invalid. Run 'notebooklm login' to re-authenticate."),
         "auth"),
        (FileNotFoundError("Storage file not found: /home/hermes/.notebooklm/x.json"), "auth"),
        (RuntimeError("HTTP 401 calling LIST_NOTEBOOKS: Unauthorized"), "auth"),
        (RuntimeError("HTTP 403 calling ASK: Forbidden"), "auth"),
        (ValueError("NotebookLM redirected this request to its region / anti-abuse access gate: "
                    "https://notebooklm.google (location=unsupported)."), "gate"),
        (RuntimeError("Server error 500 calling LIST_NOTEBOOKS"), "other"),
    ]
    for exc, expected in cases:
        got = _classify_error(exc)
        mark = "ok" if got == expected else "ПРОВАЛ"
        if got != expected:
            failures.append(f"классификация «{_short(exc)}»: ждали {expected}, получили {got}")
        print(f"      {mark}: {type(exc).__name__} → {got}")
    text = _auth_error_text("проверка")
    if not text.startswith(AUTH_EXPIRED_TEXT):
        failures.append("текст про истёкшую сессию отличается от обязательного")
        print("      ПРОВАЛ: текст про истёкшую сессию изменён")
    else:
        print("      ok: обязательный текст про истёкшую сессию на месте")

    # Не-аутентификационные сбои должны выходить человеческим текстом, а не голым traceback.
    class RateLimitError(RuntimeError):
        pass

    friendly = _friendly_other(RateLimitError("API rate limit exceeded calling LIST_NOTEBOOKS"))
    if "rate limit" not in friendly or not friendly.startswith("Ошибка:"):
        failures.append("сообщение про лимит частоты собирается неправильно")
        print("      ПРОВАЛ: сообщение про лимит частоты")
    else:
        print("      ok: лимит частоты и прочие сбои выходят текстом «Ошибка: …»")

    print("[5/5] форматирование выдачи")
    try:
        notebooks = [_FakeNotebook("11112222333344445555", "Дело Хромых", 7)]
        out = _format_notebooks(notebooks)
        assert "Дело Хромых" in out and "источников: 7" in out
        sources = [
            _FakeSource("s1", "Договор займа.pdf", "pdf", 2),
            _FakeSource("s2", "Расписка", "image", 1),
        ]
        out = _format_sources("Дело Хромых", "1111", sources)
        assert "PDF" in out and "обрабатывается" in out
        result = _FakeResult(
            "Заём подтверждён распиской.",
            [_FakeRef("s1", 1, "Заёмщик получил 500 000 рублей")],
        )
        out = _format_answer("Дело Хромых", "1111", "Был ли заём?", result,
                             {"s1": "Договор займа.pdf"})
        assert "Договор займа.pdf" in out and "Заёмщик получил" in out
        print("      ok: список блокнотов, список источников, ответ с цитатой")
    except Exception as exc:
        failures.append(f"форматирование: {_short(exc)}")
        print(f"      ПРОВАЛ: {_short(exc)}")

    print()
    if failures:
        print("== selftest ПРОВАЛЕН ==")
        for failure in failures:
            print(f"  - {failure}")
        return 1
    print("== selftest пройден (сеть не задействована) ==")
    return 0


async def main():
    async with stdio_server() as (rd, wr):
        await app.run(rd, wr, app.create_initialization_options())


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(_selftest())
    asyncio.run(main())
