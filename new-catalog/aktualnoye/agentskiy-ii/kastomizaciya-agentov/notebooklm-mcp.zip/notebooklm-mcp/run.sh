#!/bin/bash
exec /home/hermes/notebooklm-mcp/.venv/bin/python /home/hermes/notebooklm-mcp/server.py
