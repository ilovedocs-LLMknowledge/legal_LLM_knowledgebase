# NotebookLM Plugin

Integration with Google NotebookLM for managing notebooks, sources, and AI-generated content.

## Overview

This plugin connects Claude to Google NotebookLM via a local MCP server, enabling:

- Creating, listing, renaming, and deleting notebooks
- Adding and managing sources (URLs and text)
- Getting AI-generated summaries of notebook content
- Asking questions about notebook content
- Generating podcast-style audio overviews
- Generating quizzes based on notebook content

## Setup

### 1. Clone or copy the MCP server

You need the `server.py` file from the `notebooklm-mcp` repository. Place it anywhere on your machine.

### 2. Install dependencies

```bash
# Create a virtual environment (recommended)
python -m venv .venv

# Activate it
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# Install dependencies
pip install mcp notebooklm
```

### 3. Authenticate with Google

```bash
notebooklm login
```

This will open a browser window for Google account authorization. You only need to do this once (the session token is stored locally).

### 4. Set environment variables

The plugin uses two environment variables to locate the MCP server:

| Variable | Description | Example |
|----------|-------------|---------|
| `NOTEBOOKLM_PYTHON` | Path to Python interpreter (defaults to `python` if not set) | `C:\Users\Me\notebooklm-mcp\.venv\Scripts\python.exe` |
| `NOTEBOOKLM_SERVER` | Path to `server.py` | `C:\Users\Me\notebooklm-mcp\server.py` |

Set them in your system environment or in your shell profile:

```bash
# Windows (PowerShell)
[Environment]::SetEnvironmentVariable("NOTEBOOKLM_PYTHON", "C:\path\to\.venv\Scripts\python.exe", "User")
[Environment]::SetEnvironmentVariable("NOTEBOOKLM_SERVER", "C:\path\to\server.py", "User")

# macOS/Linux (~/.bashrc or ~/.zshrc)
export NOTEBOOKLM_PYTHON="/path/to/.venv/bin/python"
export NOTEBOOKLM_SERVER="/path/to/server.py"
```

## Components

| Component  | Description                                |
|------------|--------------------------------------------|
| Skill      | `notebooklm` — triggers on NotebookLM requests |
| MCP Server | Local stdio server for NotebookLM API      |

## Usage

Trigger the skill by mentioning NotebookLM or related actions:

- "Покажи мои блокноты в NotebookLM"
- "Создай блокнот"
- "Добавь источник в блокнот"
- "Сделай подкаст по блокноту"
- "Сгенерируй квиз"
- "О чём этот блокнот?"

## Available Tools

| Tool | Description |
|------|-------------|
| `notebooklm_list_notebooks` | List all notebooks |
| `notebooklm_create_notebook` | Create a notebook |
| `notebooklm_delete_notebook` | Delete a notebook |
| `notebooklm_rename_notebook` | Rename a notebook |
| `notebooklm_summary` | Get AI summary |
| `notebooklm_add_source` | Add a source (URL/text) |
| `notebooklm_list_sources` | List sources |
| `notebooklm_delete_source` | Delete a source |
| `notebooklm_ask` | Ask a question |
| `notebooklm_generate_audio` | Generate podcast |
| `notebooklm_generate_quiz` | Generate quiz |
| `notebooklm_auth_check` | Check authentication |
